//Class: Product
//Represents a product from the store, has a product number, name,
//quantity, model, manufacturer, description, clearance status, and price
//User creates products by entering the qualities listed above.

import java.util.Scanner;

public class Product {

    int productNumber;
    String productName;
    int productQty;
    String productModel;
    String productManufacturer;
    String productDescription;
    Boolean isClearance;
    double productPrice;

    //Scanner class to read input from user
    Scanner pInput = new Scanner(System.in);

    //Constructor
    public Product() {

        System.out.print("Enter product number (Enter a value between 0000000 and 9999999, integers only): ");

        //verify that the product number is between 0000000 and 9999999, throws custom exception if not
//        if((productNumber) < 1 || (productNumber > 999)) {
//            throw new InvalidDataException("Invalid data entered. Book ID number must be between 0000000 and 9999999");
//        }

        this.productNumber = pInput.nextInt();
        pInput.nextLine();

        System.out.print("Enter product name: ");
        this.productName = pInput.nextLine();

        System.out.print("Enter product quantity (integers only): ");
        this.productQty = pInput.nextInt();
        pInput.nextLine();

        System.out.print("Enter product model: ");
        this.productModel = pInput.nextLine();

        System.out.print("Enter product manufacturer: ");
        this.productManufacturer = pInput.nextLine();

        System.out.print("Enter product description: ");
        this.productDescription = pInput.nextLine();

        //how would I change this from True / False to Yes / No?
        System.out.print("Is this product on clearance? (True / False): ");
        this.isClearance = pInput.nextBoolean();

        System.out.print("Enter product price (Enter a value between $0000.00 and $9999.99): ");
        this.productPrice = pInput.nextDouble();
        pInput.nextLine();

    }//end of public class Product




}
