//Class: ProductList, will work to store all the product objects made in the Products Class.
//ProductList class will store the product menu.

import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.File;

import static java.lang.Integer.parseInt;

public class ProductList {
    //array full of Product Objects from Product Class
    Product[] productList = new Product[100];

    //User input Scanner class object
    Scanner input = new Scanner(System.in);

    //count attribute that keeps track of the current product count
    public static int count;

    //method 1: DisplayMenu
    public void DisplayMenu(){

        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println("1. Add Product");
        System.out.println("2. Modify Product");
        System.out.println("3. Delete Product");
        System.out.println("4. Add Clearance Status to Product");
        System.out.println("5. Upload Products from File");
        System.out.println("6. Display All Products");
        System.out.println("0. Exit Program");
        System.out.println("----------------------------------------------------------------------------------------------------------");

    }//end of public void displayMenu()

    //method 2: AddProduct
    public void AddProduct(Product p){

        if(count < productList.length){
            productList[count] = p;
            count++;
            System.out.println("Product " + p.productNumber + " added successfully to the database.");
        } else if (count == 100){
            System.out.println("Product database is full!");
        }//end of if else

    }//end of public void AddProduct(Product p)

    //method 3: modifyProduct
    public void modifyProduct(){

        int choice;
        Scanner ModifiedInput = new Scanner(System.in);
        Scanner attributeChoice = new Scanner(System.in);

        System.out.print("Enter product Number you wish to modify: ");
        String pNum = input.nextLine();

        //cannot read field "productNumber" because "this.productList[ProductList.count]" is null
        for(int i = 0; i < productList.length; i++ ){
            if(parseInt(pNum) == (productList[i].productNumber)){

                //once the number has been found, the user will choose what attribute to modify
                System.out.println(pNum + " has been found, what attribute would you like to modify?");

                do {

                    DisplayProductAttributes();
                    choice = attributeChoice.nextInt();

                    switch(choice){
                        case 1:
                            System.out.println("Enter new Product Number: ");
                            productList[i].productNumber = ModifiedInput.nextInt();
                            break;
                        case 2:
                            System.out.println("Enter new Product Name: ");
                            productList[i].productName = ModifiedInput.nextLine();
                            break;
                        case 3:
                            System.out.println("Enter new Product Quantity: ");
                            productList[i].productQty = ModifiedInput.nextInt();
                            break;
                        case 4:
                            System.out.println("Enter new Product Model: ");
                            productList[i].productModel = ModifiedInput.nextLine();
                            break;
                        case 5:
                            System.out.println("Enter new Product Manufacturer: ");
                            productList[i].productManufacturer = ModifiedInput.nextLine();
                            break;
                        case 6:
                            System.out.println("Enter new Product Description: ");
                            productList[i].productDescription = ModifiedInput.nextLine();
                            break;
                        case 7:
                            System.out.println("Enter new Product Clearance Status: ");
                            productList[i].isClearance = ModifiedInput.nextBoolean();
                            break;
                        case 8:
                            System.out.println("Enter new Product Price: ");
                            productList[i].productPrice = ModifiedInput.nextDouble();
                            break;
                        case 0:
                            System.out.println("0. Exit Modify Product");
                            return;
                        default:
                            System.out.println("Invalid choice, choose from choices 0-8.");
                    }

                }while(parseInt(pNum) == (productList[i].productNumber));

                return;

            }
        }
    }

    //method 4: deleteProduct
    public void deleteProduct(String pNum){

        showAllProduct();

        System.out.println("Enter the product number you want to delete: ");
        int productNumber  = input.nextInt();

        for(int i = 0; i < count; i++){

            if(productNumber == productList[i].productNumber){
                productList[count - 1] = null;
                count--;
                System.out.println("Product " + pNum + " deleted successfully from the database.");
                return;
            }//end of if(productNumber == productList[i].productNumber)
            else{
                System.out.println("Product " + pNum + " does not exist in the database.");
            }

        }//end of for(int i = 0; i < count; i++)

    }//end of public void deleteProduct(String pNum)

    //method 5: showAllProduct
    public void showAllProduct(){

        System.out.println("Showing all products and their attributes from the database.");
        System.out.print("Product Number - ");
        System.out.print("Product Name - ");
        System.out.print("Product Quantity - ");
        System.out.print("Product Model - ");
        System.out.print("Product Manufacturer - ");
        System.out.print("Product Description - ");
        System.out.print("Product Clearance Status - ");
        System.out.println("Product Price");

        if(count == 0)
        {
            System.out.println("There are no products in the database.");
        }
        else{
            for(int i = 0; i < count; i++){
                System.out.print(count + ". ");
                System.out.print(productList[i].productNumber);
                System.out.print("\t" + productList[i].productName);
                System.out.print("\t" + productList[i].productQty);
                System.out.print("\t" + productList[i].productModel);
                System.out.print("\t" + productList[i].productManufacturer);
                System.out.print("\t" + productList[i].productDescription);
                System.out.print("\t" + productList[i].isClearance);
                System.out.println("\t" + "$" + productList[i].productPrice);
            }
        }
    }

    //Method 6: DisplayProductAttributes menu for the modifyProduct method
    public void DisplayProductAttributes(){

        System.out.println("----------------------------------------------------------------------------------------------------------");
        System.out.println("1. Product Number.");
        System.out.println("2. Product Name.");
        System.out.println("3. Product Quantity.");
        System.out.println("4. Product Model.");
        System.out.println("5. Product Manufacturer.");
        System.out.println("6. Product Description");
        System.out.println("7. Product Clearance Status.");
        System.out.println("8. Product Price.");
        System.out.println("9. Exit Modify Product.");
        System.out.println("----------------------------------------------------------------------------------------------------------");

    }//end of public void displayMenu()

    //Method 7: addClearanceStatus
    public void addClearanceStatus(){

        showAllProduct();

        System.out.println("Which product would you like to change the clearance status of?");
        int productChoice = input.nextInt();

        for(int i = 0; i < productList.length; i++ ) {
            if(productChoice == productList[i].productNumber){

                productList[i].productPrice -= (productList[i].productPrice * .25);
                productList[i].isClearance = true;
                System.out.println("Product " + productList[i].productNumber + " has been set to be on clearance.");
                return;

            }

            //maybe make this work?
//            else if (productList[i].isClearance == true)
//            {
//                System.out.println(productList[i].productNumber + " is already in clearance, would you like to remove the clearance status?");
//
//            }
        }



    }

    //Make this method work
//    public Product[] uploadProductFile() throws FileNotFoundException {
//
//        //"C:\Users\Luis\IdeaProjects\DMS_Project\123test.txt"
//        System.out.println("Enter file name (Add .txt at the end): ");
//
//        String FileName = input.next();
//
//        File file = new File(FileName);
//
//        Scanner inputFile;
//
//        //Product File Attributes
//        int fileProductNumber;
//        String fileProductName;
//        int fileProductQty;
//        String fileProductModel;
//        String fileProductManufacturer;
//        String fileProductDescription;
//        Boolean fileIsClearance;
//        double fileProductPrice;
//
//        if(file.exists()){
//            inputFile = new Scanner(file);
//            while(inputFile.hasNext() && count < 100)
//            {
//                fileProductNumber = inputFile.nextInt();
//                fileProductName = inputFile.nextLine();
//                fileProductQty =  inputFile.nextInt();
//                fileProductModel =  inputFile.nextLine();
//                fileProductManufacturer = inputFile.nextLine();
//                fileProductDescription  = inputFile.nextLine();
//                fileIsClearance =  inputFile.nextBoolean();
//                fileProductPrice =  inputFile.nextDouble();
//
//                productList[count++] = new Product();
//
//                System.out.println(productList[count-1].productNumber + " has been uploaded to the database successfully.");
//
//            }
//
//        }
//
//        return productList;
//
//    }



}
