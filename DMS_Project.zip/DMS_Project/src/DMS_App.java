import java.io.FileNotFoundException;
import java.util.Scanner;

public class DMS_App {
    public static void main(String[] args) throws FileNotFoundException {

        Scanner userInput = new Scanner(System.in);

        //creating object of ProductList
        ProductList productList = new ProductList();

        //User's menu choice
        int choice;

        //do while loop for the menu
        do{
            productList.DisplayMenu();
            choice = userInput.nextInt();

            switch(choice){
                case 1:
                    Product product = new Product();
                    productList.AddProduct(product);
                    break;
                case 2:
                    productList.modifyProduct();
                    break;
                case 3:
                    String productNum = userInput.nextLine();
                    productList.deleteProduct(productNum);
                    break;
                case 4:
                    productList.addClearanceStatus();
                    break;
                case 5:
//                    productList.uploadProductFile();
                    break;
                case 6:
                    productList.showAllProduct();
                    break;
            }
        }while(choice != 0);
    }
}
