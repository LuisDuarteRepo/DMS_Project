public interface Associate {
    //When this interface is implemented by another class, that class will define what happens in work()

    void work();

}
